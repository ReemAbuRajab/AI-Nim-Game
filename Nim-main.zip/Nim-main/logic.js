// Constants
const PLAYER = 'Player';
const AI = 'AI';
const EASY = 'easy';
const MEDIUM = 'medium';
const HARD = 'hard';

// Current game state
let currentPlayer = PLAYER;
let difficulty = '';

// Define a function to set the difficulty level for the game
function setDifficulty(level) {
    // Log the chosen difficulty level to the console
    console.log(`Difficulty selected: ${level}`);
    // Set the difficulty level
    difficulty = level;
    // Hide the difficulty selection menu
    document.getElementById('difficulty').style.display = 'none';
    // Show the game board
    document.getElementById('game-container').style.display = 'block';
    // Display which player's turn it is
    document.getElementById('turnDisplay').style.display = 'block';
    document.getElementById('turnDisplay').innerText = `${currentPlayer}'s Turn`;
}

// Add event listeners to the difficulty buttons to set the game difficulty
document.getElementById('easy').addEventListener('click', () => setDifficulty('easy'));
document.getElementById('medium').addEventListener('click', () => setDifficulty('medium'));
document.getElementById('hard').addEventListener('click', () => setDifficulty('hard'));

// Define a function to remove a specified number of matchsticks from a row
function removeMatchsticks(row, count) {
    return new Promise((resolve) => {
        console.log(`Called removeMatchsticks(${row}, ${count}); ▼`);

        // Select the row from which to remove matchsticks
        const selectedRow = document.querySelector(`.matchstick-row[data-row="${row}"]`);

        // console.log(selectedRow.innerHTML);

        // Check if the selected row is valid
        if (selectedRow.children.length === 0) {
            console.error(`No row found with data-row="${row}".`);
            return;
        }

        function removeNextMatchstick(iteration) {
            if (iteration < count && selectedRow.children.length > 0) {
                console.log(`removing ${iteration + 1} out of ${count}`)
                while (1) {
                    if (selectedRow.removeChild(selectedRow.lastChild)) {
                        break;
                    }
                }
                console.log(`Deletion success: ${Boolean(selectedRow.removeChild(selectedRow.lastChild))}`);
                // Proceed to the next iteration asynchronously
                setTimeout(() => removeNextMatchstick(iteration + 1), 210);
            } else {
                // Once all matchsticks are removed, resolve the promise
                checkGameOver();
                togglePlayer();
                resolve();
            }
        }

        // Start the removal process
        removeNextMatchstick(0);
    });
}

// Define a function to check if all matchsticks have been removed, signaling the end of the game
function checkGameOver() {
    // Select all the matchsticks on the board
    const allMatchsticks = document.querySelectorAll('.matchstick');
    // Check if there are no matchsticks left
    if (allMatchsticks.length === 0) {
        // Notify players of the winner
        alert(`${currentPlayer} wins!`);
        // Update the turn display with the winner
        document.getElementById('turnDisplay').innerText = `${currentPlayer} wins!`;
        // Prevent further interaction with the game board
        rows.forEach(row => {
            row.style.pointerEvents = 'none';
        });

        return;
    } else {
        // If the game is not over, update the turn display
        document.getElementById('turnDisplay').innerText = `${currentPlayer}'s Turn`;
    }
}

// Toggle between player and AI
function togglePlayer() {
    currentPlayer = (currentPlayer === PLAYER) ? AI : PLAYER;
    updateTurnDisplay();
    if (currentPlayer === AI) {
        setTimeout(aiMove, 1500);
    }
}

function updateTurnDisplay() {
    const turnDisplayElement = document.getElementById('turnDisplay');

    if (!turnDisplayElement) {
        console.error('Turn display element not found');
        return;
    }

    if (currentPlayer === PLAYER) {
        turnDisplayElement.innerText = "Player's Turn";
    } else if (currentPlayer === AI) {
        turnDisplayElement.innerText = "AI's Turn";
    } else {
        turnDisplayElement.innerText = "Unknown Turn";
    }
}

// AI move logic
function aiMove() {
    switch (difficulty) {
        case EASY:
            makeRandomMove();
            break;
        case MEDIUM:
            makeMediumMove();
            break;
        case HARD:
            makeHardMove();
            break;
        default:
            console.error("Invalid difficulty level");
            break;
    }
}

// Define a function to execute a random move for the AI on easy difficulty
async function makeRandomMove() {
    // Gather all rows that have at least one matchstick
    const availableRows = Array.from(document.querySelectorAll('.matchstick-row'))
        .filter(row => row.querySelectorAll('.matchstick').length > 0);
    // Check if there are any rows available to make a move
    if (availableRows.length > 0) {
        // Select a random row from the available rows
        const randomRow = availableRows[Math.floor(Math.random() * availableRows.length)];
        // Count how many matchsticks are in the randomly selected row
        const rowMatchsticks = randomRow.querySelectorAll('.matchstick').length;
        // Decide a random number of matchsticks to remove
        const removeCount = Math.floor(Math.random() * rowMatchsticks) + 1;
        // Execute the move by removing the chosen number of matchsticks from the chosen row
        await removeMatchsticks(randomRow.getAttribute('data-row'), removeCount);
    }
}

// Define a function to retrieve the current state of the rows as an array
function getCurrentRows() {
    // Select all the rows on the board
    let rows = document.querySelectorAll('.matchstick-row');
    // Transform the NodeList into an array containing the number of matchsticks in each row
    let currentRows = Array.from(rows).map(row => row.children.length);
    return currentRows;
}

// Define a function to evaluate the current state of the game
function evaluateGameState(rows) {
    // Initialize the xorSum variable, which will be used for the game evaluation
    let xorSum = 0;
    // Calculate the XOR sum of the number of matchsticks in each row
    rows.forEach(row => {
        xorSum ^= row;
    });
    // Return the XOR sum, which helps in determining the favorability of the position
    return xorSum;
}

// Define the alpha-beta pruning algorithm to calculate the best move for the AI
function alphaBetaPruning(rows, depth, alpha, beta, maximizingPlayer) {
    // Base case: if the depth is 0 or there are no matchsticks left, evaluate the game state
    if (depth === 0 || rows.every(row => row === 0)) {
        return evaluateGameState(rows);
    }
    // If it's the maximizing player's turn (AI)
    if (maximizingPlayer) {
        // Initialize the best evaluation to negative infinity
        let maxEval = -Infinity;
        // Iterate through each row
        for (let index = 0; index < rows.length; index++) {
            // If the current row has matchsticks
            if (rows[index] > 0) {
                // Copy the current state of the rows and simulate removing one matchstick
                let newRows = [...rows];
                newRows[index] -= 1;
                // Recursively call the algorithm, decreasing depth and switching to the minimizing player
                let eval = alphaBetaPruning(newRows, depth - 1, alpha, beta, false);
                // Update the best evaluation if necessary
                maxEval = Math.max(maxEval, eval);
                // Update the alpha value
                alpha = Math.max(alpha, eval);
                // Cut off the remaining branches if alpha is greater or equal to beta
                if (beta <= alpha) {
                    break;
                }
            }
        }
        return maxEval;
    } else {
        // If it's the minimizing player's turn (human)
        // Initialize the best evaluation to infinity
        let minEval = Infinity;
        // Iterate through each row
        for (let index = 0; index < rows.length; index++) {
            // If the current row has matchsticks
            if (rows[index] > 0) {
                // Copy the current state of the rows and simulate removing one matchstick
                let newRows = [...rows];
                newRows[index] -= 1;
                // Recursively call the algorithm, decreasing depth and switching to the maximizing player
                let eval = alphaBetaPruning(newRows, depth - 1, alpha, beta, true);
                // Update the best evaluation if necessary
                minEval = Math.min(minEval, eval);
                // Update the beta value
                beta = Math.min(beta, eval);
                // Cut off the remaining branches if beta is less or equal to alpha
                if (beta <= alpha) {
                    break;
                }
            }
        }
        return minEval;
    }
}

// Define a function for the AI to make a medium difficulty move
async function makeMediumMove() {
    // Initialize best value to the lowest possible number
    let bestVal = -Infinity;
    // Initialize the best move, which has not been chosen yet
    let bestMove = {
        row: -1,
        count: 0
    };
    // Get the current state of the rows on the board
    let currentRows = getCurrentRows();

    console.log("Current rows before AI move:", currentRows);

    // Filter out rows that have no matchsticks left
    let validRows = currentRows.map((count, index) => ({ count, index: currentRows.length - index })).filter(row => row.count > 0);

    if (validRows.length === 0) {
        console.log("No valid moves available for AI.");
        togglePlayer();
        return;
    }

    // Iterate through the valid rows to find the best move
    for (let row of validRows) {
        // If the current row has matchsticks
        if (row.count > 0) {
            // Copy the current state of the rows and simulate removing one matchstick
            let newRows = [...currentRows];
            newRows[row.index - 1] -= 1; // Adjusting for zero-based index
            // Call the alpha-beta pruning algorithm with limited depth
            let moveVal = alphaBetaPruning(newRows, 3, -Infinity, Infinity, true);
            // If the move value is better than the best value, update the best move
            if (moveVal > bestVal) {
                bestVal = moveVal;
                bestMove = {
                    row: row.index,
                    count: 1
                };
            }
        }
    }

    // If a best move was found, execute it
    if (bestMove.row >= 1) {
        await removeMatchsticks(bestMove.row, bestMove.count);
    } else {
        console.log(`Invalid row index generated by AI: ${bestMove.row}`);
        alert(`${currentPlayer} Gave Up...`);
    }

    // Check game over and toggle player after AI's move
}

// Define a function for the AI to make a hard difficulty move
async function makeHardMove() {
    // Initialize best value to the lowest possible number
    let bestVal = -Infinity;
    // Initialize the best move, which has not been chosen yet
    let bestMove = {
        row: -1,
        count: 0
    };
    // Get the current state of the rows on the board
    let currentRows = getCurrentRows();
    // Iterate through the rows to find the best move
    currentRows.forEach((row, index) => {
        // If the current row has matchsticks
        if (row > 0) {
            // Copy the current state of the rows and simulate removing one matchstick
            let newRows = [...currentRows];
            newRows[index] -= 1;
            // Call the alpha-beta pruning algorithm with greater depth
            let moveVal = alphaBetaPruning(newRows, 5, -Infinity, Infinity, false);
            // If the move value is better than the best value, update the best move
            if (moveVal > bestVal) {
                bestVal = moveVal;
                bestMove = {
                    row: currentRows.length - index,
                    count: 1
                };
            }
        }
    });
    // If a best move was found, execute it
    if (bestMove.row >= 1) {
        await removeMatchsticks(bestMove.row, bestMove.count);
    }
}

// Add click event listeners to each row for the player to remove matchsticks
const rows = document.querySelectorAll('.matchstick-row');
rows.forEach(row => {
    row.addEventListener('click', function () {
        if (difficulty && currentPlayer === 'Player') {
            // Ask the player for the number of sticks to remove
            let count = parseInt(prompt("Enter the number of sticks to remove:"));

            // Validate the input
            if (!isNaN(count) && count > 0 && count <= row.children.length) {
                removeMatchsticks(row.getAttribute('data-row'), count);
            } else {
                alert("Invalid number of sticks.");
            }
        }
    });
});

// Initially hide the turn display element
document.getElementById('turnDisplay').style.display = 'none';